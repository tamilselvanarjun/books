1. footer.html is set according to sphinx_rtd_theme.

2. rename layout.html is set for other themes.